<html>

<head>

</head>

<body>

<?php

$delimiter = ";"; // Die Begrenzungszeichenkette

$content = file('Kundendaten.csv'); // content hat datei

$content_new = str_replace(";Mr;",";Herr;", $content); //Zeichenfolge ersetzen mit Herr und jetzt new_content hat datei

$content_new = str_replace(";Mrs;",";Frau;",$content_new); // Zeichenfolge ersetzen mit Frau in new_content

echo "<table>\n"; // Tabelle erstellung
 
foreach ($content_new as $row) // conent als Reihe

{ 

echo "\t<tr>\n"; // Tabelle Reihe
 
$cells = explode($delimiter, $row); //Teilt eine Zeichenkette anhand einer Zeichenkette
 
foreach ($cells as $cell) // PHP loop

{

echo sprintf("\t\t<td>%s</td>\n", $cell); // Tabelle ausgibt
	
}
 
echo "\t</tr>\n";

}

echo "</table>\n";  // Tabelle ende

?>

</body>

</html>
