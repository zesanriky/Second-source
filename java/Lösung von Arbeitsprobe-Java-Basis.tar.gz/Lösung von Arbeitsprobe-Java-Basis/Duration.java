package de.narz.echtzeit.commons.concurrent;

/**
 * Schnittstellte zur Ermittlung von Ausführungsdauern.
 * @author gtsakuma
 */
public interface Duration {

	/**
	 * Liefert die <em>maximale</em> Ausführungsdauer.
	 * @return Die maximale Ausführungsdauer in Millisekunden.
	 */
	public long getMax();

	/**
	 * Liefert die <em>minimale</em> Ausführungsdauer.
	 * @return Die minimale Ausführungsdauer in Millisekunden.
	 */
	public long getMin();

	/**
	 * Liefert die <em>durchschnittliche</em> Ausführungsdauer.
	 * @return Die minimale Ausführungsdauer in Millisekunden.
	 */
	public long getAvg();

}
