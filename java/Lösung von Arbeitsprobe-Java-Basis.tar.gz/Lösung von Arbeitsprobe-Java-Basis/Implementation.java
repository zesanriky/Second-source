package de.narz.echtzeit.commons.concurrent;

import java.util.Random;

import java.util.concurrent.TimeUnit;

//Code gestartet
	
public class Implementation implements Duration, DurationSensor{
	
public static void main(String[] a) throws InterruptedException {

Implementation t = new  Implementation();
	  
t.getMax();

t.getMin();
	 
t.getAvg(); 
	  
Thread thread = new Thread();

displayStateAndIsAlive(thread);
		
thread.start();
		
displayStateAndIsAlive(thread);
	
t.getSnapShot();

Thread.sleep(1000);
	
displayStateAndIsAlive(thread);
		
t.register(5000);

}
  
// Duration methods
  
@Override
public long getMax() {
	
// TODO Auto-generated method stub
	
System.out.println("\nGröße und kleine aufgaben laufen........");
	
long startTime = System.currentTimeMillis();
	
//  Größe aufgaben laufen
	
try {

Thread.sleep(5000);
		
} catch (InterruptedException e) {
			
// TODO Auto-generated catch block
	
e.printStackTrace();
		
}
	    	    
long estimatedTime = System.currentTimeMillis() - startTime;

System.out.println("\nDie erste Ausführungsdauer in Millisekunden:- " + estimatedTime + "(milliseconds)");

long startTime1 = System.currentTimeMillis();

//  Kline aufgaben laufen

try {

Thread.sleep(2000);

} catch (InterruptedException e) {

// TODO Auto-generated catch block
	
e.printStackTrace();
	
}
    	    
long estimatedTime1 = System.currentTimeMillis() - startTime1;

System.out.println("\nDie zweite Ausführungsdauer in Millisekunden:- " + estimatedTime1 + "(milliseconds)");

System.out.println("\nDie maximale Ausführungsdauer in Millisekunden  : "+Math.max(estimatedTime, estimatedTime1));      

return 0;

}

@Override

public long getMin() {

// TODO Auto-generated method stub
	
System.out.println("\nKleine und Größe  aufgaben laufen......");
	
long startTime = System.currentTimeMillis();
	
//   Kline aufgaben laufen
	
try {

Thread.sleep(1000);
	
} catch (InterruptedException e) {

// TODO Auto-generated catch block

e.printStackTrace();

}
	    	    
long estimatedTime = System.currentTimeMillis() - startTime;

System.out.println("\nDie dritte Ausführungsdauer in Millisekundens:- " + estimatedTime + "(milliseconds)");

long startTime1 = System.currentTimeMillis();

//  Größe aufgaben laufen

try {

Thread.sleep(4000);
	
} catch (InterruptedException e) {
		
// TODO Auto-generated catch block
	
e.printStackTrace();
	
}
    	    
long estimatedTime1 = System.currentTimeMillis() - startTime1;

System.out.println("\nDie vierte Ausführungsdauer in Millisekundens:- " + estimatedTime1 + "(milliseconds)");


System.out.println("\nDie minimale Ausführungsdauer in Millisekunden  : "+Math.min(estimatedTime, estimatedTime1));    

return 0;

}

@Override

public long getAvg() {

// TODO Auto-generated method stub

System.out.println("\nGröße und kleine aufgaben laufen........");
	
long startTime = System.currentTimeMillis();
	
//  Größe aufgaben laufen
	
try {
			
Thread.sleep(5000);

} catch (InterruptedException e) {
	
// TODO Auto-generated catch block
	
e.printStackTrace();

}
	    	    
long estimatedTime = System.currentTimeMillis() - startTime;

System.out.println("\nDie erste Ausführungsdauer in Millisekunden:- " + estimatedTime + "(milliseconds)");

long startTime1 = System.currentTimeMillis();

//  Kline aufgaben laufen

try {

Thread.sleep(2000);
		
} catch (InterruptedException e) {
	
// TODO Auto-generated catch block
	
e.printStackTrace();

}
    	    
long estimatedTime1 = System.currentTimeMillis() - startTime1;

System.out.println("\nDie zweite Ausführungsdauer in Millisekunden:- " + estimatedTime1 + "(milliseconds)");

System.out.println("\nDie Ausführungsdauer in Millisekunden  : "+(estimatedTime+estimatedTime1/2));      

System.out.println("\nKleine und Größe  aufgaben laufen......");

long startTime11 = System.currentTimeMillis();

//   Kline aufgaben laufen

try {
		
Thread.sleep(1000);
	
} catch (InterruptedException e) {
		
// TODO Auto-generated catch block
	
e.printStackTrace();

}
    	    
long estimatedTime11 = System.currentTimeMillis() - startTime11;

System.out.println("\nDie dritte Ausführungsdauer in Millisekundens:- " + estimatedTime11 + "(milliseconds)");

long startTime111 = System.currentTimeMillis();

//Größe aufgaben laufen

try {
	
Thread.sleep(4000);

} catch (InterruptedException e) {
	
// TODO Auto-generated catch block
	
e.printStackTrace();
	
}
	    
long estimatedTime111 = System.currentTimeMillis() - startTime111;

System.out.println("\nDie vierte Ausführungsdauer in Millisekundens:- " + estimatedTime111 + "(milliseconds)");


System.out.println("\nDie Ausführungsdauer für erste und zweite aufgaben in Millisekunden : "+(estimatedTime+estimatedTime1/2));      


System.out.println("\nDie Ausführungsdauer für dritte und vierte aufgaben in Millisekunden : "+(estimatedTime11+estimatedTime111/2));


System.out.println("\nDie minimale Ausführungsdauer in Millisekunden : "+Math.min(estimatedTime+estimatedTime1/2, estimatedTime11

+estimatedTime111/2));    


return 0;

}

// DurationSensor methods


@Override

public Duration getSnapShot() {
	
System.out.println("\nRunnable Job wird ausgeführt");

// TODO Auto-generated method stub

return null;

}


public static void displayStateAndIsAlive(Thread thread) {
	
// java.lang.Thread.State can be NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING, TERMINATED
	
System.out.println("\nState:" + thread.getState());

System.out.println("\nIst lebendig ?:" + thread.isAlive());
	
}

@Override

public void register(long durationMS) {
	
// TODO Auto-generated method stub

	
System.out.println("\nAusführungsdauer ........");
	
long startTime = System.currentTimeMillis();
	
//  Ausführungsdauer 
	
try {

Thread.sleep(5000);

} catch (InterruptedException e) {
	
// TODO Auto-generated catch block
	
e.printStackTrace();

}
	    	    
long estimatedTime = System.currentTimeMillis() - startTime;

System.out.println("\nDie Ausführungsdauer in Millisekunden:- " + estimatedTime + "(milliseconds)");

	
}


}

// Code beendet		
		  
		
	


